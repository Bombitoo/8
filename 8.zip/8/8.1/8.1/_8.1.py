print(*[int(input()) for _ in range(int(input()))][::-1])
